# Bootstrap v3 datetimepicker widget

# Version 3 has been deprecated, please upgrade to v4.

![DateTimePicker](http://i.imgur.com/nfnvh5g.png)

## [View the manual and demos](http://eonasdan.github.io/bootstrap-datetimepicker/version3/)
